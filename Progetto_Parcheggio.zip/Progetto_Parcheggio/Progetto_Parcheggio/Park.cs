﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Parcheggio
{
    internal class Park
    {
        public Ingresso[] Ingressi { get; set; }
        public Uscita[] Uscite { get; set; }
        public int Posti { get; set; }
        public Semaphore semaforo = new Semaphore(1, 1);
        


        public Park(int nIngressi, int nUscite, int posti)
        {
            Ingressi = new Ingresso [nIngressi];
            for(int i = 0; i < nIngressi; i++)
                Ingressi[i] = new Ingresso(new Random().Next(1, 10), this);

            Uscite = new Uscita[nUscite];
            for (int i = 0; i < nUscite; i++)
                Uscite[i] = new Uscita(new Random().Next(1, 10), this);
            Posti = posti;
        }
    }
}
