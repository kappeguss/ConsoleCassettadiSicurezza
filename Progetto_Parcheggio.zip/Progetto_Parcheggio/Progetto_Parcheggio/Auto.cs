﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Parcheggio
{
    internal class Auto : MioThread 
    {
        public int TempoS { get; set; }
        public int Targa { get; set; }
        public string Marca { get; set; }
        public string Modello { get; set; }

        private static Random random = new Random();
        Park parchegio;

        public Auto(int tempoS, int targa, string marca, string modello, Park p)
        {
            TempoS = random.Next(10000, 100); ;
            Targa = targa;
            Marca = marca;
            Modello = modello;
            parchegio = p;
        }
       public void Run(object f)
        {
            (f as Form1).listBox1.Items.Add(this);
                parchegio.Ingressi[new Random().Next(0, parchegio.Ingressi.Length)].Entra(this);
        }

    }
}
