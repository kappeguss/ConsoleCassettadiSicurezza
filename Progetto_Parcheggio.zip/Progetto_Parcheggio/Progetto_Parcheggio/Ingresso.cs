﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Parcheggio
{
    internal class Ingresso 
    {
        public int TempoI { get; set; }
        Queue<Auto> coda = new Queue<Auto>();
        private  Semaphore semaforo = new Semaphore(1, 1);
        Park parchegio;
        public Ingresso(int tempoI, Park p)
        {
            TempoI = tempoI;
            parchegio = p;
        }
        public void Entra(Auto auto)
        {
            parchegio.semaforo.WaitOne();
            if (parchegio.Posti > 0)
            {
                semaforo.WaitOne();
                parchegio.Posti--;
                parchegio.semaforo.Release();
                Thread.Sleep(TempoI);
                semaforo.Release();
               
            }
            else
                parchegio.semaforo.Release();
            
        }
    }
}
